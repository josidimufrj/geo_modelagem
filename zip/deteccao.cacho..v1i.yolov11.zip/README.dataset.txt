# detecção > 2026-07-07 8:12pm
https://universe.roboflow.com/josiane-coelho-de-oliveira/deteccao-k32pw

Provided by a Roboflow user
License: CC BY 4.0

